### finetune the code

'/Users/zhenkai/Documents/personal/Projects/AgenticRecommender/finetune/scripts/finetune_lora.py''/Users/zhenkai/Documents/personal/Projects/AgenticRecommender/finetune/scripts/i
  nfer_lora.py'. this is the two  scripts I have for using SFTTrainer for lora finetuning. Can you follow the parameters in /Users/zhenkai/Documents/personal/Projects/AgenticRecommender/finetune/configs/qwen3_movielens_qlora.yaml. update the code accordingly.